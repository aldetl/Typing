Table of contents

[TOC]

---



# overview 



## v1.3.2

2021-12-06, 

- improve performance.
- `LControlKey, RControlKey, LMenu, RMenu` can be set on the right side now.



## v1.3.1

2021-12-03, 

- Shift选择应该可以了；
已知bug：
- （2021-12-03）设置‘=’号右边LControlKey, RControlKey, LMenu, RMenu不能被发送，需用Control和Alt。但LShiftKey, RShiftKey, Shift均可以。下次更新会修复。



## v1.3.0

2021-12-02， 

+ CapsLock状态提示;
+ Shift键选择文字;

三种选择方式；
1，进入vim-mode，按V键使能shift，之后按“移动命令键”选择文字；
2，进入vim-mode，按“shift+移动键”选择文字；
3，任意状态下，按组合键，例如“CapsLock+LShiftKey+U=RShiftKey+Home”, 或者“LMenu+U=RShiftKey+Home”（需要在设置中开启）
备注：

- 第一种方式支持设置step移动步长，后两种不支持。
- 文字选择功能是通过发送shift修饰键实现的，但软件不默认添加shift到发送按键（即使shift被按下），所有命令需要在配置文件中列出，这主要是想让shift组合键可以实现任意配置功能；

bug

- 在某些系统上shift选择不起作用，请等更新。。）



## v1.2.0

2021-10-22,
+vim模式定时自动退出功能;
+vim模式提示功能(跟随鼠标显示提示);

## v1.1.0

2021-10-20,

- 支持单键，组合键命令混合模式；
- 可以自定义要发送的按键了；
- 取消了连击模式键功能；

## v1.0.2.1

2021-10-14, 

- fix bug：1.0.2 high cpu usage

## v1.0.2

2021-10-14, 

- fix bug: press the mode-key twice continuously.
- support emacs-style hotkeys.



## v1.0. 1

2021-10-12，

- custom setting in `configuration.ini`



## v1.0.0

2021-10-11， 
